<?php
shell_exec('sudo python /home/lighton.py');
header("location:light.php");
?>