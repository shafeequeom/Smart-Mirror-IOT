<?php shell_exec('sudo bash /var/www/html/sm/webcam.sh'); 
   header("location:camera.php");	
?>