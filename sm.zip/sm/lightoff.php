<?php
shell_exec('sudo python /home/lightoff.py');
   header("location:light.php");	
?>